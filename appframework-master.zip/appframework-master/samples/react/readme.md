#sample

This sample is to show basic usage of React and App Framework UI.  This does not go into more advanced features, such as page routing/navigation.  This shows how to create custom React components and load them in an App Framework UI app, along with responding to custom "longTap" events.