#sample

This sample is to show basic usage of Backbone and App Framework UI.  This does not go into more advanced features, such as page routing/navigation.  This shows initiating the view when App Framework UI is ready, and responding to a custom "longTap" event.