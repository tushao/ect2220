#Splashscreen

This plugin will hide a splashscreen when the $.afui.ready has triggered.  Simply include the script and it will remove the div with id="splashscreen"

```

 <div id="splashscreen" class='ui-loader heavy'>
	App Framework
	<br>
	<br> 
	<span class='ui-icon ui-icon-loading spin'></span>
	<h1>Starting app</h1>
 </div>

```

